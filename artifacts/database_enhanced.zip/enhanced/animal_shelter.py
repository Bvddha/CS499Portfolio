"""Database access layer for the Grazioso Salvare dashboard."""

from __future__ import annotations

import csv
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


class AnimalShelter:
    ALLOWED_FIELDS = {
        "id",
        "name",
        "animal_type",
        "breed",
        "sex_upon_outcome",
        "age_upon_outcome_in_weeks",
        "location_lat",
        "location_long",
        "outcome_type",
    }

    def __init__(self, database_path: str = "grazioso_salvare.db", seed_path: Optional[str] = "seed_data.csv"):
        self.database_path = str(database_path)
        self.connection = sqlite3.connect(self.database_path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self._create_schema()
        if seed_path:
            self._seed_if_empty(Path(seed_path))

    def _create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS animals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                animal_type TEXT NOT NULL,
                breed TEXT NOT NULL,
                sex_upon_outcome TEXT NOT NULL,
                age_upon_outcome_in_weeks INTEGER NOT NULL CHECK(age_upon_outcome_in_weeks >= 0),
                location_lat REAL NOT NULL CHECK(location_lat BETWEEN -90 AND 90),
                location_long REAL NOT NULL CHECK(location_long BETWEEN -180 AND 180),
                outcome_type TEXT NOT NULL DEFAULT 'Unknown'
            );

            CREATE INDEX IF NOT EXISTS idx_animals_type ON animals(animal_type);
            CREATE INDEX IF NOT EXISTS idx_animals_breed ON animals(breed);
            CREATE INDEX IF NOT EXISTS idx_animals_age ON animals(age_upon_outcome_in_weeks);
            CREATE INDEX IF NOT EXISTS idx_animals_sex ON animals(sex_upon_outcome);
            """
        )
        self.connection.commit()

    def _seed_if_empty(self, seed_path: Path) -> None:
        count = self.connection.execute("SELECT COUNT(*) FROM animals").fetchone()[0]
        if count or not seed_path.exists():
            return
        with seed_path.open("r", encoding="utf-8", newline="") as handle:
            records = list(csv.DictReader(handle))
        for record in records:
            self.create(record)

    @staticmethod
    def _normalize_record(record: Dict[str, Any]) -> Dict[str, Any]:
        cleaned = dict(record)
        if "age_upon_outcome_in_weeks" in cleaned:
            cleaned["age_upon_outcome_in_weeks"] = int(cleaned["age_upon_outcome_in_weeks"])
        if "location_lat" in cleaned:
            cleaned["location_lat"] = float(cleaned["location_lat"])
        if "location_long" in cleaned:
            cleaned["location_long"] = float(cleaned["location_long"])
        return cleaned

    def create(self, data: Dict[str, Any]) -> int:
        required = {
            "name", "animal_type", "breed", "sex_upon_outcome",
            "age_upon_outcome_in_weeks", "location_lat", "location_long"
        }
        missing = required.difference(data)
        if missing:
            raise ValueError(f"Missing required fields: {', '.join(sorted(missing))}")

        record = self._normalize_record(data)
        columns = [
            "name", "animal_type", "breed", "sex_upon_outcome",
            "age_upon_outcome_in_weeks", "location_lat", "location_long", "outcome_type"
        ]
        values = [record.get(col, "Unknown" if col == "outcome_type" else None) for col in columns]
        cursor = self.connection.execute(
            f"INSERT INTO animals ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
            values,
        )
        self.connection.commit()
        return int(cursor.lastrowid)

    def _build_where(self, query: Optional[Dict[str, Any]]) -> Tuple[str, List[Any]]:
        if not query:
            return "", []
        clauses: List[str] = []
        params: List[Any] = []
        for field, condition in query.items():
            if field not in self.ALLOWED_FIELDS:
                raise ValueError(f"Unsupported query field: {field}")
            if isinstance(condition, dict):
                for operator, value in condition.items():
                    if operator == "$in":
                        values = list(value)
                        if not values:
                            clauses.append("1 = 0")
                        else:
                            clauses.append(f"{field} IN ({', '.join('?' for _ in values)})")
                            params.extend(values)
                    elif operator == "$lte":
                        clauses.append(f"{field} <= ?")
                        params.append(value)
                    elif operator == "$gte":
                        clauses.append(f"{field} >= ?")
                        params.append(value)
                    elif operator == "$like":
                        clauses.append(f"{field} LIKE ?")
                        params.append(value)
                    else:
                        raise ValueError(f"Unsupported query operator: {operator}")
            else:
                clauses.append(f"{field} = ?")
                params.append(condition)
        return " WHERE " + " AND ".join(clauses), params

    def read(self, query: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        where, params = self._build_where(query)
        cursor = self.connection.execute(f"SELECT * FROM animals{where} ORDER BY id", params)
        return [dict(row) for row in cursor.fetchall()]

    def update(self, query: Dict[str, Any], changes: Dict[str, Any]) -> int:
        if not changes:
            return 0
        cleaned = self._normalize_record(changes)
        assignments = []
        values: List[Any] = []
        for field, value in cleaned.items():
            if field not in self.ALLOWED_FIELDS or field == "id":
                raise ValueError(f"Unsupported update field: {field}")
            assignments.append(f"{field} = ?")
            values.append(value)
        where, params = self._build_where(query)
        if not where:
            raise ValueError("Update requires a filter.")
        cursor = self.connection.execute(
            f"UPDATE animals SET {', '.join(assignments)}{where}", values + params
        )
        self.connection.commit()
        return int(cursor.rowcount)

    def delete(self, query: Dict[str, Any]) -> int:
        where, params = self._build_where(query)
        if not where:
            raise ValueError("Delete requires a filter.")
        cursor = self.connection.execute(f"DELETE FROM animals{where}", params)
        self.connection.commit()
        return int(cursor.rowcount)

    def close(self) -> None:
        self.connection.close()
