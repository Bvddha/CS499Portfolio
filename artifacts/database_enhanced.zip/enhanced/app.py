from pathlib import Path

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, State, callback_context, dash_table, dcc, html, no_update

from animal_shelter import AnimalShelter

BASE_DIR = Path(__file__).resolve().parent
db = AnimalShelter(BASE_DIR / "grazioso_salvare.db", BASE_DIR / "seed_data.csv")

WATER_BREEDS = ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]
MOUNTAIN_BREEDS = ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]
DISASTER_BREEDS = ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]


def base_dog_query():
    return {
        "animal_type": "Dog",
        "age_upon_outcome_in_weeks": {"$lte": 104},
        "sex_upon_outcome": {"$in": ["Intact Male", "Intact Female"]},
    }


def query_for_filter(filter_type):
    if filter_type == "Water":
        query = base_dog_query()
        query["breed"] = {"$in": WATER_BREEDS}
        return query
    if filter_type == "Mountain":
        query = base_dog_query()
        query["breed"] = {"$in": MOUNTAIN_BREEDS}
        return query
    if filter_type == "Disaster":
        query = base_dog_query()
        query["breed"] = {"$in": DISASTER_BREEDS}
        return query
    return {}


def records_for_filter(filter_type):
    return db.read(query_for_filter(filter_type))


app = Dash(__name__)
app.title = "Grazioso Salvare Dashboard"

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "1400px", "margin": "0 auto", "padding": "20px"},
    children=[
        html.H1("Grazioso Salvare Rescue Dashboard", style={"textAlign": "center"}),
        html.Div("Gavin Elliott - CS 499 Database Enhancement", style={"textAlign": "center", "marginBottom": "20px"}),
        html.Label("Rescue Type Filter", style={"fontWeight": "bold"}),
        dcc.RadioItems(
            id="filter-type",
            options=[
                {"label": "Reset (All)", "value": "Reset"},
                {"label": "Water Rescue", "value": "Water"},
                {"label": "Mountain/Wilderness Rescue", "value": "Mountain"},
                {"label": "Disaster/Tracking", "value": "Disaster"},
            ],
            value="Reset",
            inline=True,
            style={"marginBottom": "15px"},
        ),
        dash_table.DataTable(
            id="datatable-id",
            page_size=10,
            sort_action="native",
            filter_action="native",
            row_selectable="single",
            selected_rows=[],
            style_table={"overflowX": "auto"},
            style_cell={"textAlign": "left", "minWidth": "110px", "maxWidth": "260px", "whiteSpace": "normal"},
            style_header={"fontWeight": "bold"},
        ),
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "20px", "marginTop": "20px"},
            children=[dcc.Graph(id="graph-id"), dcc.Graph(id="map-id")],
        ),
        html.Hr(),
        html.H2("Database Record Maintenance"),
        html.P("Select a row to update or delete it, or enter values and create a new record."),
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "repeat(4, minmax(180px, 1fr))", "gap": "10px"},
            children=[
                dcc.Input(id="name", placeholder="Animal name", type="text"),
                dcc.Input(id="animal-type", placeholder="Animal type", type="text", value="Dog"),
                dcc.Input(id="breed", placeholder="Breed", type="text"),
                dcc.Dropdown(id="sex", placeholder="Sex upon outcome", options=[
                    {"label": v, "value": v} for v in ["Intact Male", "Intact Female", "Neutered Male", "Spayed Female"]
                ]),
                dcc.Input(id="age", placeholder="Age in weeks", type="number", min=0),
                dcc.Input(id="latitude", placeholder="Latitude", type="number", min=-90, max=90, step=0.0001),
                dcc.Input(id="longitude", placeholder="Longitude", type="number", min=-180, max=180, step=0.0001),
                dcc.Input(id="outcome", placeholder="Outcome type", type="text", value="Unknown"),
            ],
        ),
        html.Div(
            style={"display": "flex", "gap": "10px", "marginTop": "12px"},
            children=[
                html.Button("Create Record", id="create-record", n_clicks=0),
                html.Button("Update Selected", id="update-record", n_clicks=0),
                html.Button("Delete Selected", id="delete-record", n_clicks=0),
            ],
        ),
        html.Div(id="status-message", style={"marginTop": "10px", "fontWeight": "bold"}),
        dcc.Store(id="refresh-token", data=0),
    ],
)


@app.callback(
    Output("datatable-id", "data"),
    Output("datatable-id", "columns"),
    Output("datatable-id", "selected_rows"),
    Input("filter-type", "value"),
    Input("refresh-token", "data"),
)
def update_table(filter_type, _refresh_token):
    records = records_for_filter(filter_type)
    columns = [{"name": key.replace("_", " ").title(), "id": key} for key in records[0].keys()] if records else []
    return records, columns, []


@app.callback(Output("graph-id", "figure"), Input("datatable-id", "derived_virtual_data"))
def update_graph(view_data):
    records = view_data or []
    if not records:
        return px.pie(title="Breed Distribution")
    frame = pd.DataFrame(records)
    return px.pie(frame, names="breed", title="Breed Distribution of Visible Records")


@app.callback(
    Output("map-id", "figure"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
)
def update_map(view_data, selected_rows):
    records = view_data or []
    if not records:
        return px.scatter_map(pd.DataFrame({"lat": [], "lon": []}), lat="lat", lon="lon", title="Animal Location")
    frame = pd.DataFrame(records)
    selected = selected_rows[0] if selected_rows else 0
    selected = min(selected, len(frame) - 1)
    row = frame.iloc[[selected]]
    fig = px.scatter_map(
        row,
        lat="location_lat",
        lon="location_long",
        hover_name="name",
        hover_data=["breed", "animal_type", "outcome_type"],
        zoom=10,
        title="Selected Animal Location",
    )
    fig.update_layout(map_style="open-street-map", margin={"r": 0, "t": 45, "l": 0, "b": 0})
    return fig


@app.callback(
    Output("name", "value"),
    Output("animal-type", "value"),
    Output("breed", "value"),
    Output("sex", "value"),
    Output("age", "value"),
    Output("latitude", "value"),
    Output("longitude", "value"),
    Output("outcome", "value"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
    prevent_initial_call=True,
)
def fill_form(view_data, selected_rows):
    if not view_data or not selected_rows:
        return (no_update,) * 8
    row = view_data[selected_rows[0]]
    return (
        row.get("name"), row.get("animal_type"), row.get("breed"), row.get("sex_upon_outcome"),
        row.get("age_upon_outcome_in_weeks"), row.get("location_lat"), row.get("location_long"), row.get("outcome_type")
    )


@app.callback(
    Output("status-message", "children"),
    Output("refresh-token", "data"),
    Input("create-record", "n_clicks"),
    Input("update-record", "n_clicks"),
    Input("delete-record", "n_clicks"),
    State("datatable-id", "derived_virtual_data"),
    State("datatable-id", "derived_virtual_selected_rows"),
    State("name", "value"),
    State("animal-type", "value"),
    State("breed", "value"),
    State("sex", "value"),
    State("age", "value"),
    State("latitude", "value"),
    State("longitude", "value"),
    State("outcome", "value"),
    State("refresh-token", "data"),
    prevent_initial_call=True,
)
def maintain_record(create_clicks, update_clicks, delete_clicks, view_data, selected_rows,
                    name, animal_type, breed, sex, age, latitude, longitude, outcome, refresh_token):
    trigger = callback_context.triggered_id
    try:
        if trigger == "delete-record":
            if not view_data or not selected_rows:
                return "Select a record before deleting.", refresh_token
            record_id = view_data[selected_rows[0]]["id"]
            deleted = db.delete({"id": record_id})
            return f"Deleted {deleted} record.", refresh_token + 1

        data = {
            "name": name,
            "animal_type": animal_type,
            "breed": breed,
            "sex_upon_outcome": sex,
            "age_upon_outcome_in_weeks": age,
            "location_lat": latitude,
            "location_long": longitude,
            "outcome_type": outcome or "Unknown",
        }
        if any(data[key] in (None, "") for key in ["name", "animal_type", "breed", "sex_upon_outcome", "age_upon_outcome_in_weeks", "location_lat", "location_long"]):
            return "Complete all required fields before saving.", refresh_token

        if trigger == "create-record":
            record_id = db.create(data)
            return f"Created record {record_id}.", refresh_token + 1

        if trigger == "update-record":
            if not view_data or not selected_rows:
                return "Select a record before updating.", refresh_token
            record_id = view_data[selected_rows[0]]["id"]
            updated = db.update({"id": record_id}, data)
            return f"Updated {updated} record.", refresh_token + 1
    except (ValueError, TypeError) as exc:
        return f"Unable to save record: {exc}", refresh_token
    return no_update, refresh_token


if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=8050)
