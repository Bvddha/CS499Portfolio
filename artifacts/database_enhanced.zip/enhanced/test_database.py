from pathlib import Path
import tempfile
from animal_shelter import AnimalShelter

with tempfile.TemporaryDirectory() as tmp:
    db_path = Path(tmp) / "test.db"
    db = AnimalShelter(db_path, Path(__file__).resolve().parent / "seed_data.csv")
    initial = db.read({})
    assert len(initial) >= 20
    new_id = db.create({
        "name": "Test Animal", "animal_type": "Dog", "breed": "Labrador Retriever Mix",
        "sex_upon_outcome": "Intact Male", "age_upon_outcome_in_weeks": 40,
        "location_lat": 30.2672, "location_long": -97.7431, "outcome_type": "Adoption"
    })
    assert db.read({"id": new_id})[0]["name"] == "Test Animal"
    assert db.update({"id": new_id}, {"name": "Updated Animal"}) == 1
    assert db.read({"id": new_id})[0]["name"] == "Updated Animal"
    assert db.delete({"id": new_id}) == 1
    assert db.read({"id": new_id}) == []
    db.close()
print("Database smoke test passed.")
