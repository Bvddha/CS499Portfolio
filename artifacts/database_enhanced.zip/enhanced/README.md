# Grazioso Salvare Database Enhancement

This version keeps the rescue filtering, table, chart, and location display from the original dashboard and adds a self-contained relational database layer. It runs locally without MongoDB.

## Enhancements

- SQLite database that is created automatically on first run
- Parameterized database operations and field validation
- Database indexes for common rescue-filter fields
- Create, read, update, and delete operations through a dedicated data-access class
- Rescue filters for water, mountain/wilderness, and disaster/tracking dogs
- Interactive table, breed distribution chart, and selected-animal map
- Record-maintenance controls for adding, updating, and deleting animals
- Seed data so the program starts with usable records

## Run on Windows

1. Open the `enhanced` folder in File Explorer.
2. Double-click `run_dashboard.bat`.
3. The script creates a virtual environment, installs the required packages, and starts the dashboard.
4. Open `http://127.0.0.1:8050` in a browser if it does not open automatically.

## Run from a terminal

```text
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

On macOS or Linux, activate the virtual environment with `source .venv/bin/activate`.

The database file `grazioso_salvare.db` is created in the same folder as the application. Delete it if you want the application to rebuild the database from `seed_data.csv`.
