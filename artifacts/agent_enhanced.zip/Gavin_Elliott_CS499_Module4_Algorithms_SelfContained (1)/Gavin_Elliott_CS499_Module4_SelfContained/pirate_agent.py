import argparse
import datetime
import random
import sys

import numpy as np

try:
    import tensorflow as tf
    from tensorflow.keras import Sequential
    from tensorflow.keras.layers import Dense, PReLU
    from tensorflow.keras.models import clone_model
except ImportError:
    tf = None

LEFT = 0
UP = 1
RIGHT = 2
DOWN = 3

ACTIONS = {
    LEFT: "left",
    UP: "up",
    RIGHT: "right",
    DOWN: "down",
}

MAZE = np.array([
    [1., 0., 1., 1., 1., 1., 1., 1.],
    [1., 0., 1., 1., 1., 0., 1., 1.],
    [1., 1., 1., 1., 0., 1., 0., 1.],
    [1., 1., 1., 0., 1., 1., 1., 1.],
    [1., 1., 0., 1., 1., 1., 1., 1.],
    [1., 1., 1., 0., 1., 0., 0., 0.],
    [1., 1., 1., 0., 1., 1., 1., 1.],
    [1., 1., 1., 1., 0., 1., 1., 1.],
], dtype=np.float32)


class TreasureMaze:
    def __init__(self, maze, pirate=(0, 0)):
        self._maze = np.array(maze, dtype=np.float32)
        self.nrows, self.ncols = self._maze.shape
        self.target = (self.nrows - 1, self.ncols - 1)
        self.free_cells = [
            (row, col)
            for row in range(self.nrows)
            for col in range(self.ncols)
            if self._maze[row, col] == 1.0 and (row, col) != self.target
        ]
        if pirate not in self.free_cells:
            raise ValueError("Pirate must start on a free maze cell.")
        self.reset(pirate)

    def reset(self, pirate):
        if pirate not in self.free_cells:
            raise ValueError("Pirate must start on a free maze cell.")
        self.maze = np.copy(self._maze)
        self.state = (pirate[0], pirate[1], "start")
        self.min_reward = -0.5 * self.maze.size
        self.total_reward = 0.0
        self.visited = set()
        return self.observe()

    def valid_actions(self, cell=None):
        if cell is None:
            row, col, _ = self.state
        else:
            row, col = cell

        actions = []
        if col > 0 and self.maze[row, col - 1] == 1.0:
            actions.append(LEFT)
        if row > 0 and self.maze[row - 1, col] == 1.0:
            actions.append(UP)
        if col < self.ncols - 1 and self.maze[row, col + 1] == 1.0:
            actions.append(RIGHT)
        if row < self.nrows - 1 and self.maze[row + 1, col] == 1.0:
            actions.append(DOWN)
        return actions

    def update_state(self, action):
        row, col, _ = self.state
        self.visited.add((row, col))
        valid = self.valid_actions((row, col))

        if not valid:
            mode = "blocked"
        elif action not in valid:
            mode = "invalid"
        else:
            mode = "valid"
            if action == LEFT:
                col -= 1
            elif action == UP:
                row -= 1
            elif action == RIGHT:
                col += 1
            elif action == DOWN:
                row += 1

        self.state = (row, col, mode)

    def get_reward(self):
        row, col, mode = self.state
        if (row, col) == self.target:
            return 1.0
        if mode == "blocked":
            return self.min_reward - 1.0
        if mode == "invalid":
            return -0.75
        if (row, col) in self.visited:
            return -0.25
        return -0.04

    def game_status(self):
        row, col, _ = self.state
        if self.total_reward < self.min_reward:
            return "lose"
        if (row, col) == self.target:
            return "win"
        return "not_over"

    def observe(self):
        canvas = np.copy(self.maze)
        row, col, _ = self.state
        canvas[row, col] = 0.5
        return canvas.reshape((1, -1)).astype(np.float32)

    def act(self, action):
        self.update_state(action)
        reward = self.get_reward()
        self.total_reward += reward
        return self.observe(), reward, self.game_status()


class GameExperience:
    def __init__(self, model, target_model, max_memory=2000, discount=0.95):
        self.model = model
        self.target_model = target_model
        self.max_memory = max_memory
        self.discount = discount
        self.memory = []

    def remember(self, episode):
        self.memory.append(episode)
        if len(self.memory) > self.max_memory:
            del self.memory[0]

    def predict(self, envstate, target=False):
        network = self.target_model if target else self.model
        state = np.asarray(envstate, dtype=np.float32)
        if state.ndim == 1:
            state = np.expand_dims(state, axis=0)
        return network(state, training=False).numpy()

    def get_data(self, data_size=64):
        if not self.memory:
            raise ValueError("Experience memory is empty.")

        sample_size = min(data_size, len(self.memory))
        indices = np.random.choice(len(self.memory), sample_size, replace=False)
        env_size = self.memory[0][0].shape[1]
        inputs = np.zeros((sample_size, env_size), dtype=np.float32)
        targets = np.zeros((sample_size, len(ACTIONS)), dtype=np.float32)

        for i, index in enumerate(indices):
            envstate, action, reward, next_state, game_status = self.memory[index]
            inputs[i] = envstate[0]
            targets[i] = self.predict(envstate)[0]

            if game_status in ("win", "lose"):
                targets[i, action] = reward
            else:
                next_q = self.predict(next_state, target=True)[0]
                targets[i, action] = reward + self.discount * np.max(next_q)

        return inputs, targets


def build_model(maze):
    require_tensorflow()
    model = Sequential([
        tf.keras.Input(shape=(maze.size,)),
        Dense(maze.size),
        PReLU(),
        Dense(maze.size),
        PReLU(),
        Dense(len(ACTIONS)),
    ])
    return model


def require_tensorflow():
    if tf is None:
        raise RuntimeError(
            "TensorFlow is not installed. Create the virtual environment and run "
            "'python -m pip install -r requirements.txt' before training."
        )


def format_time(seconds):
    if seconds < 400:
        return "%.1f seconds" % float(seconds)
    if seconds < 4000:
        return "%.2f minutes" % (seconds / 60.0)
    return "%.2f hours" % (seconds / 3600.0)


def choose_greedy_action(model, envstate, valid_actions):
    state = np.asarray(envstate, dtype=np.float32)
    if state.ndim == 1:
        state = np.expand_dims(state, axis=0)
    q_values = model(state, training=False).numpy()[0]
    return max(valid_actions, key=lambda action: q_values[action])


def play_game(model, qmaze, pirate_cell, max_steps=None):
    qmaze.reset(pirate_cell)
    envstate = qmaze.observe()
    limit = max_steps if max_steps is not None else qmaze.maze.size * 4

    for _ in range(limit):
        valid_actions = qmaze.valid_actions()
        if not valid_actions:
            return False
        action = choose_greedy_action(model, envstate, valid_actions)
        envstate, _, game_status = qmaze.act(action)
        if game_status == "win":
            return True
        if game_status == "lose":
            return False
    return False


def completion_check(model, maze, max_steps=None):
    qmaze = TreasureMaze(maze)
    for cell in qmaze.free_cells:
        if qmaze.valid_actions(cell) and not play_game(model, qmaze, cell, max_steps):
            return False
    return True


def qtrain(model, maze, n_epoch=1500, max_memory=2000, data_size=64,
           min_replay_size=64, target_update_freq=50,
           completion_patience=3, print_every=10, seed=42):
    require_tensorflow()
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

    epsilon = 1.0
    epsilon_min = 0.05
    epsilon_decay = 0.995
    qmaze = TreasureMaze(maze)
    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())
    experience = GameExperience(model, target_model, max_memory=max_memory)
    optimizer = tf.keras.optimizers.Adam()
    loss_fn = tf.keras.losses.MeanSquaredError()

    win_history = []
    history = {"win_rate": [], "loss": [], "epsilon": [], "steps": [], "reward": []}
    history_window = qmaze.maze.size // 2
    consecutive_completion_checks = 0
    start_time = datetime.datetime.now()

    @tf.function
    def train_step(x, y):
        with tf.GradientTape() as tape:
            q_values = model(x, training=True)
            loss = loss_fn(y, q_values)
        gradients = tape.gradient(loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
        return loss

    for epoch in range(n_epoch):
        qmaze.reset(random.choice(qmaze.free_cells))
        envstate = qmaze.observe()
        game_over = False
        episode_steps = 0
        episode_reward = 0.0
        batch_losses = []

        while not game_over:
            previous_envstate = envstate
            valid_actions = qmaze.valid_actions()
            if not valid_actions:
                win_history.append(0)
                break

            if np.random.random() < epsilon:
                action = random.choice(valid_actions)
            else:
                action = choose_greedy_action(model, envstate, valid_actions)

            envstate, reward, game_status = qmaze.act(action)
            episode_steps += 1
            episode_reward += float(reward)

            if game_status == "win":
                win_history.append(1)
                game_over = True
            elif game_status == "lose":
                win_history.append(0)
                game_over = True

            experience.remember([previous_envstate, action, reward, envstate, game_status])

            if len(experience.memory) >= min_replay_size:
                inputs, targets = experience.get_data(data_size)
                batch_loss = train_step(inputs, targets)
                batch_losses.append(float(batch_loss.numpy()))

        if (epoch + 1) % target_update_freq == 0:
            target_model.set_weights(model.get_weights())

        recent = win_history[-history_window:]
        win_rate = sum(recent) / len(recent) if recent else 0.0
        mean_loss = float(np.mean(batch_losses)) if batch_losses else 0.0

        history["win_rate"].append(win_rate)
        history["loss"].append(mean_loss)
        history["epsilon"].append(epsilon)
        history["steps"].append(episode_steps)
        history["reward"].append(episode_reward)

        epsilon = max(epsilon * epsilon_decay, epsilon_min)

        if win_rate >= 0.999 and completion_check(model, maze):
            consecutive_completion_checks += 1
        else:
            consecutive_completion_checks = 0

        if epoch % print_every == 0 or consecutive_completion_checks:
            elapsed = datetime.datetime.now() - start_time
            print(
                "Epoch {:04d}/{:d} | Loss {:.4f} | Win rate {:.3f} | "
                "Epsilon {:.3f} | Steps {:d} | Time {}".format(
                    epoch, n_epoch - 1, mean_loss, win_rate, epsilon,
                    episode_steps, format_time(elapsed.total_seconds())
                )
            )

        if consecutive_completion_checks >= completion_patience:
            print("Completion check passed {} times at epoch {}.".format(
                completion_patience, epoch
            ))
            break

    print("Training complete in", format_time((datetime.datetime.now() - start_time).total_seconds()))
    return history


def save_training_plots(history, filename="training_history.png"):
    import matplotlib.pyplot as plt

    epochs = np.arange(1, len(history["win_rate"]) + 1)
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes[0, 0].plot(epochs, history["win_rate"])
    axes[0, 0].set_title("Win Rate")
    axes[0, 1].plot(epochs, history["loss"])
    axes[0, 1].set_title("Training Loss")
    axes[1, 0].plot(epochs, history["epsilon"])
    axes[1, 0].set_title("Exploration Rate")
    axes[1, 1].plot(epochs, history["steps"])
    axes[1, 1].set_title("Steps Per Episode")
    for axis in axes.flat:
        axis.set_xlabel("Epoch")
    fig.tight_layout()
    fig.savefig(filename, dpi=150)
    plt.close(fig)


def smoke_test():
    qmaze = TreasureMaze(MAZE)
    assert qmaze.observe().shape == (1, MAZE.size)
    start_actions = qmaze.valid_actions((0, 0))
    assert start_actions == [DOWN]
    _, reward, status = qmaze.act(DOWN)
    assert status == "not_over"
    assert reward <= 0

    qmaze.reset((7, 6))
    assert RIGHT in qmaze.valid_actions()
    _, reward, status = qmaze.act(RIGHT)
    assert status == "win"
    assert reward == 1.0
    print("Environment smoke test passed.")


def main():
    parser = argparse.ArgumentParser(description="Self-contained Pirate Intelligent Agent")
    parser.add_argument("--epochs", type=int, default=1500)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--model-file", default="pirate_agent.keras")
    parser.add_argument("--plot-file", default="training_history.png")
    args = parser.parse_args()

    if args.smoke_test:
        smoke_test()
        return

    require_tensorflow()
    model = build_model(MAZE)
    history = qtrain(model, MAZE, n_epoch=args.epochs)
    passed = completion_check(model, MAZE)
    print("Completion check:", passed)
    model.save(args.model_file)
    save_training_plots(history, args.plot_file)
    print("Saved model to", args.model_file)
    print("Saved training plot to", args.plot_file)


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as exc:
        print(exc, file=sys.stderr)
        sys.exit(1)
