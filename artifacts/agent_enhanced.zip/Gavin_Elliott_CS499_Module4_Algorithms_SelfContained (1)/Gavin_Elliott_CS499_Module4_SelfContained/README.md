# CS 499 Module Four - Pirate Intelligent Agent Enhancement

This version is self-contained. The maze environment and experience replay logic that were previously expected in `TreasureMaze.py` and `GameExperience.py` are included directly in the enhanced files, so those missing starter files are no longer required.

## Recommended setup in Visual Studio Code

Use Python 3.10 or 3.11. In VS Code, install the Python and Jupyter extensions, open this folder, and then run these commands in the integrated terminal.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python pirate_agent.py --smoke-test
python pirate_agent.py --epochs 1500
```

### Windows Command Prompt

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python pirate_agent.py --smoke-test
python pirate_agent.py --epochs 1500
```

The smoke test checks the maze logic without requiring a full training run. The training command creates `pirate_agent.keras` and `training_history.png` when it completes.

## Running the notebook in VS Code

Open `Gavin_Elliott_ProjectTwo_Enhanced_SelfContained.ipynb`, choose the `.venv` interpreter as the notebook kernel, and select **Run All**. The notebook includes the environment, replay-memory class, enhanced Q-training logic, evaluation, and plots.

## Main enhancements

- Integrated the missing maze environment and replay-memory implementation into the artifact.
- Restricted exploitation to valid actions in the current state.
- Increased replay-memory capacity and delayed training until enough samples are stored.
- Added a target network that synchronizes on a fixed schedule.
- Applied gradual epsilon decay with a minimum exploration rate.
- Required repeated completion checks before early stopping.
- Tracked win rate, loss, exploration rate, steps, and reward for evaluation.
- Added a standalone Python entry point so the project can be run and tested directly in VS Code.

## Files

- `Gavin_Elliott_ProjectTwo_Enhanced_SelfContained.ipynb` - enhanced notebook for the milestone.
- `pirate_agent.py` - runnable VS Code/Python version of the same enhancement.
- `requirements.txt` - Python dependencies.
- `README.md` - setup and test instructions.
- `original/Gavin_elliott_ProjectTwo_Original.ipynb` - original artifact for comparison.
