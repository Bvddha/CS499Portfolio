# CS 499 Milestone Two Submission

This package contains both versions of the Contact Service required for the software design and engineering enhancement.

## Original Contact Service

The `Original_Contact_Service` folder contains the CS 320 artifact as originally submitted, including the Java classes, JUnit tests, project document, and original README.

## Enhanced Contact Service

The `Enhanced_Contact_Service` folder contains the completed Spring Boot REST enhancement. Start with its `README.md` for configuration, API endpoints, design trade-offs, and testing instructions. The `ENHANCEMENT_SUMMARY.md` file provides a shorter comparison of the original and enhanced designs, while `TEST_RESULTS.md` records the final automated test result.
