package com.gavinelliott.contactservice.dto;

import com.gavinelliott.contactservice.model.Contact;

public record ContactResponse(
        String contactId,
        String firstName,
        String lastName,
        String phone,
        String address) {

    public static ContactResponse from(Contact contact) {
        return new ContactResponse(
                contact.getContactId(),
                contact.getFirstName(),
                contact.getLastName(),
                contact.getPhone(),
                contact.getAddress());
    }
}
