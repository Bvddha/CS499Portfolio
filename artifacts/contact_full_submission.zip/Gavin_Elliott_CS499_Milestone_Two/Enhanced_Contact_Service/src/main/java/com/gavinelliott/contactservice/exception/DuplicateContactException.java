package com.gavinelliott.contactservice.exception;

public class DuplicateContactException extends RuntimeException {

    public DuplicateContactException(String contactId) {
        super("A contact already exists for ID: " + contactId);
    }
}
