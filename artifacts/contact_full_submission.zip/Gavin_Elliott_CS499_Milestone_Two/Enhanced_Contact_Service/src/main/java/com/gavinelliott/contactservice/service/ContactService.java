package com.gavinelliott.contactservice.service;

import com.gavinelliott.contactservice.dto.ContactCreateRequest;
import com.gavinelliott.contactservice.dto.ContactResponse;
import com.gavinelliott.contactservice.dto.ContactUpdateRequest;
import com.gavinelliott.contactservice.exception.ContactNotFoundException;
import com.gavinelliott.contactservice.exception.DuplicateContactException;
import com.gavinelliott.contactservice.model.Contact;
import com.gavinelliott.contactservice.repository.ContactRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class ContactService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContactService.class);

    private final ContactRepository repository;

    public ContactService(ContactRepository repository) {
        this.repository = repository;
    }

    public ContactResponse create(ContactCreateRequest request) {
        Contact contact = new Contact(
                request.contactId(),
                request.firstName(),
                request.lastName(),
                request.phone(),
                request.address());

        if (!repository.create(contact)) {
            throw new DuplicateContactException(contact.getContactId());
        }

        LOGGER.info("Created contact with ID {}", contact.getContactId());
        return ContactResponse.from(contact);
    }

    public ContactResponse findById(String contactId) {
        return ContactResponse.from(getRequired(contactId));
    }

    public List<ContactResponse> findAll() {
        return repository.findAll().stream()
                .sorted(Comparator.comparing(Contact::getContactId))
                .map(ContactResponse::from)
                .toList();
    }

    public ContactResponse update(String contactId, ContactUpdateRequest request) {
        String normalizedId = normalizeId(contactId);
        Contact current = getRequired(normalizedId);
        Contact updated = current.withUpdatedDetails(
                request.firstName(),
                request.lastName(),
                request.phone(),
                request.address());
        repository.save(updated);
        LOGGER.info("Updated contact with ID {}", normalizedId);
        return ContactResponse.from(updated);
    }

    public void delete(String contactId) {
        String normalizedId = normalizeId(contactId);
        if (!repository.deleteById(normalizedId)) {
            throw new ContactNotFoundException(normalizedId);
        }
        LOGGER.info("Deleted contact with ID {}", normalizedId);
    }

    private Contact getRequired(String contactId) {
        String normalizedId = normalizeId(contactId);
        return repository.findById(normalizedId)
                .orElseThrow(() -> new ContactNotFoundException(normalizedId));
    }

    private String normalizeId(String contactId) {
        if (contactId == null || contactId.isBlank()) {
            throw new IllegalArgumentException("Contact ID is required");
        }
        return contactId.trim();
    }
}
