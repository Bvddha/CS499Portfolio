package com.gavinelliott.contactservice.controller;

import com.gavinelliott.contactservice.dto.ContactCreateRequest;
import com.gavinelliott.contactservice.dto.ContactResponse;
import com.gavinelliott.contactservice.dto.ContactUpdateRequest;
import com.gavinelliott.contactservice.service.ContactService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/contacts")
@Tag(name = "Contacts", description = "Create, retrieve, update, and delete contact records")
public class ContactController {

    private final ContactService contactService;

    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @PostMapping
    @Operation(summary = "Create a contact")
    public ResponseEntity<ContactResponse> create(@Valid @RequestBody ContactCreateRequest request) {
        ContactResponse created = contactService.create(request);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{contactId}")
                .buildAndExpand(created.contactId())
                .toUri();
        return ResponseEntity.created(location).body(created);
    }

    @GetMapping("/{contactId}")
    @Operation(summary = "Retrieve one contact")
    public ContactResponse findById(@PathVariable String contactId) {
        return contactService.findById(contactId);
    }

    @GetMapping
    @Operation(summary = "Retrieve all contacts")
    public List<ContactResponse> findAll() {
        return contactService.findAll();
    }

    @PutMapping("/{contactId}")
    @Operation(summary = "Replace a contact's editable information")
    public ContactResponse update(
            @PathVariable String contactId,
            @Valid @RequestBody ContactUpdateRequest request) {
        return contactService.update(contactId, request);
    }

    @DeleteMapping("/{contactId}")
    @Operation(summary = "Delete a contact")
    public ResponseEntity<Void> delete(@PathVariable String contactId) {
        contactService.delete(contactId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
