package com.gavinelliott.contactservice.repository;

import com.gavinelliott.contactservice.model.Contact;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Repository
public class InMemoryContactRepository implements ContactRepository {

    private final ConcurrentMap<String, Contact> contacts = new ConcurrentHashMap<>();

    @Override
    public boolean create(Contact contact) {
        return contacts.putIfAbsent(contact.getContactId(), contact) == null;
    }

    @Override
    public Contact save(Contact contact) {
        contacts.put(contact.getContactId(), contact);
        return contact;
    }

    @Override
    public Optional<Contact> findById(String contactId) {
        return Optional.ofNullable(contacts.get(contactId));
    }

    @Override
    public List<Contact> findAll() {
        return new ArrayList<>(contacts.values());
    }

    @Override
    public boolean deleteById(String contactId) {
        return contacts.remove(contactId) != null;
    }

    @Override
    public void deleteAll() {
        contacts.clear();
    }
}
