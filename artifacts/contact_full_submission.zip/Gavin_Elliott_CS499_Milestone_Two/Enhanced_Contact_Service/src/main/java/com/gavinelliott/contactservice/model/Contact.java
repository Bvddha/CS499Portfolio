package com.gavinelliott.contactservice.model;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Immutable contact domain object. The contact ID is never changed after creation.
 */
public final class Contact {

    public static final int CONTACT_ID_MAX_LENGTH = 10;
    public static final int NAME_MAX_LENGTH = 10;
    public static final int ADDRESS_MAX_LENGTH = 30;
    public static final String PHONE_PATTERN = "\\d{10}";

    private static final Pattern TEN_DIGIT_PHONE = Pattern.compile(PHONE_PATTERN);

    private final String contactId;
    private final String firstName;
    private final String lastName;
    private final String phone;
    private final String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = validateLength(contactId, "Contact ID", CONTACT_ID_MAX_LENGTH);
        this.firstName = validateLength(firstName, "First name", NAME_MAX_LENGTH);
        this.lastName = validateLength(lastName, "Last name", NAME_MAX_LENGTH);
        this.phone = validatePhone(phone);
        this.address = validateLength(address, "Address", ADDRESS_MAX_LENGTH);
    }

    public Contact withUpdatedDetails(String firstName, String lastName, String phone, String address) {
        return new Contact(contactId, firstName, lastName, phone, address);
    }

    private static String validateLength(String value, String fieldName, int maximumLength) {
        String normalized = requireText(value, fieldName);
        if (normalized.length() > maximumLength) {
            throw new IllegalArgumentException(fieldName + " must be at most " + maximumLength + " characters");
        }
        return normalized;
    }

    private static String validatePhone(String value) {
        String normalized = requireText(value, "Phone");
        if (!TEN_DIGIT_PHONE.matcher(normalized).matches()) {
            throw new IllegalArgumentException("Phone must contain exactly 10 digits");
        }
        return normalized;
    }

    private static String requireText(String value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " cannot be null");
        }
        String normalized = value.trim();
        if (normalized.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return normalized;
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Contact contact)) {
            return false;
        }
        return contactId.equals(contact.contactId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId);
    }
}
