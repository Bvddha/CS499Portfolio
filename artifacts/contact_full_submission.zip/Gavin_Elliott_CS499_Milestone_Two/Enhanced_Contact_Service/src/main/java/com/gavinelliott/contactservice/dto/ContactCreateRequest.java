package com.gavinelliott.contactservice.dto;

import com.gavinelliott.contactservice.model.Contact;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record ContactCreateRequest(
        @NotBlank(message = "Contact ID is required")
        @Size(max = Contact.CONTACT_ID_MAX_LENGTH, message = "Contact ID must be at most 10 characters")
        String contactId,

        @NotBlank(message = "First name is required")
        @Size(max = Contact.NAME_MAX_LENGTH, message = "First name must be at most 10 characters")
        String firstName,

        @NotBlank(message = "Last name is required")
        @Size(max = Contact.NAME_MAX_LENGTH, message = "Last name must be at most 10 characters")
        String lastName,

        @NotBlank(message = "Phone is required")
        @Pattern(regexp = Contact.PHONE_PATTERN, message = "Phone must contain exactly 10 digits")
        String phone,

        @NotBlank(message = "Address is required")
        @Size(max = Contact.ADDRESS_MAX_LENGTH, message = "Address must be at most 30 characters")
        String address) {
}
