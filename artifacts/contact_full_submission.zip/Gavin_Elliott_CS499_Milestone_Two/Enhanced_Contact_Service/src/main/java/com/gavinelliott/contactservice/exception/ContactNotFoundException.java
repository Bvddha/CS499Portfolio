package com.gavinelliott.contactservice.exception;

public class ContactNotFoundException extends RuntimeException {

    public ContactNotFoundException(String contactId) {
        super("Contact was not found for ID: " + contactId);
    }
}
