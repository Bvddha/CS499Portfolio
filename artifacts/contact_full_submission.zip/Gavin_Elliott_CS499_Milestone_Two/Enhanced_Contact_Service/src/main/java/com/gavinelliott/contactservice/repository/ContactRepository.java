package com.gavinelliott.contactservice.repository;

import com.gavinelliott.contactservice.model.Contact;

import java.util.List;
import java.util.Optional;

public interface ContactRepository {

    boolean create(Contact contact);

    Contact save(Contact contact);

    Optional<Contact> findById(String contactId);

    List<Contact> findAll();

    boolean deleteById(String contactId);

    void deleteAll();
}
