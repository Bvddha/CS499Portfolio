package com.gavinelliott.contactservice.controller;

import com.gavinelliott.contactservice.repository.ContactRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "contact.api.security.username=test-user",
        "contact.api.security.password=test-password"
})
class ContactControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ContactRepository repository;

    @BeforeEach
    void clearRepository() {
        repository.deleteAll();
    }

    @Test
    void unauthenticatedRequestIsRejected() throws Exception {
        mockMvc.perform(get("/api/contacts"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void validContactCanBeCreatedAndRetrieved() throws Exception {
        mockMvc.perform(post("/api/contacts")
                        .with(httpBasic("test-user", "test-password"))
                        .contentType(APPLICATION_JSON)
                        .content(validCreateJson("c1")))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", "http://localhost/api/contacts/c1"))
                .andExpect(jsonPath("$.contactId").value("c1"));

        mockMvc.perform(get("/api/contacts/c1")
                        .with(httpBasic("test-user", "test-password")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("John"));
    }

    @Test
    void invalidPhoneProducesStandardValidationError() throws Exception {
        mockMvc.perform(post("/api/contacts")
                        .with(httpBasic("test-user", "test-password"))
                        .contentType(APPLICATION_JSON)
                        .content("""
                                {
                                  "contactId": "c1",
                                  "firstName": "John",
                                  "lastName": "Doe",
                                  "phone": "123",
                                  "address": "1 First St"
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.fieldErrors.phone").exists());
    }

    @Test
    void duplicateContactProducesConflict() throws Exception {
        createContact("c1");

        mockMvc.perform(post("/api/contacts")
                        .with(httpBasic("test-user", "test-password"))
                        .contentType(APPLICATION_JSON)
                        .content(validCreateJson("c1")))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409));
    }

    @Test
    void contactCanBeUpdatedAndDeleted() throws Exception {
        createContact("c1");

        mockMvc.perform(put("/api/contacts/c1")
                        .with(httpBasic("test-user", "test-password"))
                        .contentType(APPLICATION_JSON)
                        .content("""
                                {
                                  "firstName": "Amy",
                                  "lastName": "Wong",
                                  "phone": "9998887777",
                                  "address": "9 Ninth Ave"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contactId").value("c1"))
                .andExpect(jsonPath("$.firstName").value("Amy"));

        mockMvc.perform(delete("/api/contacts/c1")
                        .with(httpBasic("test-user", "test-password")))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/contacts/c1")
                        .with(httpBasic("test-user", "test-password")))
                .andExpect(status().isNotFound());
    }

    @Test
    void missingContactProducesNotFound() throws Exception {
        mockMvc.perform(get("/api/contacts/missing")
                        .with(httpBasic("test-user", "test-password")))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    private void createContact(String id) throws Exception {
        mockMvc.perform(post("/api/contacts")
                        .with(httpBasic("test-user", "test-password"))
                        .contentType(APPLICATION_JSON)
                        .content(validCreateJson(id)))
                .andExpect(status().isCreated());
    }

    private String validCreateJson(String id) {
        return """
                {
                  "contactId": "%s",
                  "firstName": "John",
                  "lastName": "Doe",
                  "phone": "1112223333",
                  "address": "1 First St"
                }
                """.formatted(id);
    }
}
