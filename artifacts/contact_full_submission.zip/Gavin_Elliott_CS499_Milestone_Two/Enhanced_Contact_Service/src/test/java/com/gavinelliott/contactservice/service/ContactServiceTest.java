package com.gavinelliott.contactservice.service;

import com.gavinelliott.contactservice.dto.ContactCreateRequest;
import com.gavinelliott.contactservice.dto.ContactResponse;
import com.gavinelliott.contactservice.dto.ContactUpdateRequest;
import com.gavinelliott.contactservice.exception.ContactNotFoundException;
import com.gavinelliott.contactservice.exception.DuplicateContactException;
import com.gavinelliott.contactservice.repository.InMemoryContactRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService(new InMemoryContactRepository());
    }

    @Test
    void createAndRetrieveContact() {
        ContactResponse created = service.create(createRequest("c1", "John"));

        assertEquals("c1", created.contactId());
        assertEquals(created, service.findById("c1"));
    }

    @Test
    void duplicateContactIdIsRejected() {
        service.create(createRequest("c1", "John"));

        assertThrows(DuplicateContactException.class,
                () -> service.create(createRequest("c1", "Jane")));
    }

    @Test
    void updatePreservesContactId() {
        service.create(createRequest("c1", "John"));

        ContactResponse updated = service.update(
                "c1",
                new ContactUpdateRequest("Amy", "Wong", "9998887777", "9 Ninth Ave"));

        assertEquals("c1", updated.contactId());
        assertEquals("Amy", updated.firstName());
        assertEquals("Wong", updated.lastName());
    }

    @Test
    void contactsAreReturnedInIdOrder() {
        service.create(createRequest("c2", "Jane"));
        service.create(createRequest("c1", "John"));

        List<ContactResponse> contacts = service.findAll();

        assertEquals(List.of("c1", "c2"), contacts.stream().map(ContactResponse::contactId).toList());
    }

    @Test
    void deletingMissingContactReturnsNotFound() {
        assertThrows(ContactNotFoundException.class, () -> service.delete("missing"));
    }

    @Test
    void deletingExistingContactRemovesIt() {
        service.create(createRequest("c1", "John"));

        service.delete("c1");

        assertThrows(ContactNotFoundException.class, () -> service.findById("c1"));
    }

    private ContactCreateRequest createRequest(String id, String firstName) {
        return new ContactCreateRequest(id, firstName, "Doe", "1112223333", "1 First St");
    }
}
