package com.gavinelliott.contactservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ContactTest {

    @Test
    void validValuesAreTrimmedAndStored() {
        Contact contact = new Contact(" c1 ", " John ", " Doe ", "1112223333", " 1 First St ");

        assertEquals("c1", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1 First St", contact.getAddress());
    }

    @Test
    void exactBoundaryLengthsAreAccepted() {
        Contact contact = new Contact(
                "1234567890",
                "1234567890",
                "1234567890",
                "1112223333",
                "123456789012345678901234567890");

        assertEquals(10, contact.getContactId().length());
        assertEquals(30, contact.getAddress().length());
    }

    @Test
    void valuesPastBoundaryLengthsAreRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "John", "Doe", "1112223333", "1 First St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("c1", "12345678901", "Doe", "1112223333", "1 First St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("c1", "John", "Doe", "1112223333", "1234567890123456789012345678901"));
    }

    @Test
    void phoneMustContainExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("c1", "John", "Doe", "123", "1 First St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("c1", "John", "Doe", "123456789a", "1 First St"));
    }

    @Test
    void updatedContactKeepsOriginalId() {
        Contact original = new Contact("c1", "John", "Doe", "1112223333", "1 First St");

        Contact updated = original.withUpdatedDetails("Amy", "Wong", "9998887777", "9 Ninth Ave");

        assertEquals("c1", updated.getContactId());
        assertEquals("Amy", updated.getFirstName());
    }
}
