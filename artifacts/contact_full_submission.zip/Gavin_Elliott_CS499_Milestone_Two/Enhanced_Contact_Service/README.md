# Contact Service API

This project is an enhanced version of the Contact Service originally created for CS 320. The original in-memory classes were reorganized into a Spring Boot REST API with separate controller, service, repository, model, DTO, exception, and configuration layers.

## Enhancement Highlights

- REST endpoints for creating, retrieving, updating, and deleting contacts
- Immutable contact IDs and named validation limits instead of magic numbers
- Request validation for required fields, length limits, and ten-digit phone numbers
- Thread-safe in-memory repository with atomic duplicate-ID protection
- Consistent HTTP error responses for validation failures, missing contacts, and duplicates
- HTTP Basic authentication with credentials loaded from environment variables
- Logging that records contact IDs without writing names, phone numbers, or addresses
- Unit and integration tests covering service logic, validation, authentication, and HTTP responses
- OpenAPI documentation through Swagger UI
- GitHub Actions workflow that runs the automated tests after pushes and pull requests

## Requirements

- Java 17
- Maven 3.9 or newer

## Configure and Run

Set credentials through environment variables before starting the application.

### Windows PowerShell

```powershell
$env:CONTACT_API_USERNAME="contact-user"
$env:CONTACT_API_PASSWORD="choose-a-strong-password"
mvn spring-boot:run
```

### Linux or macOS

```bash
export CONTACT_API_USERNAME="contact-user"
export CONTACT_API_PASSWORD="choose-a-strong-password"
mvn spring-boot:run
```

Swagger UI is available at `http://localhost:8080/swagger-ui.html`.

## API Endpoints

| Method | Endpoint | Purpose | Success Status |
|---|---|---|---|
| POST | `/api/contacts` | Create a contact | 201 Created |
| GET | `/api/contacts` | List all contacts | 200 OK |
| GET | `/api/contacts/{contactId}` | Retrieve one contact | 200 OK |
| PUT | `/api/contacts/{contactId}` | Replace editable contact details | 200 OK |
| DELETE | `/api/contacts/{contactId}` | Delete a contact | 204 No Content |

All contact endpoints require HTTP Basic authentication.

## Example Create Request

```bash
curl -u contact-user:choose-a-strong-password \
  -H "Content-Type: application/json" \
  -d '{"contactId":"c1","firstName":"John","lastName":"Doe","phone":"1112223333","address":"1 First St"}' \
  http://localhost:8080/api/contacts
```

## Run Tests

```bash
mvn test
```

The tests use separate test credentials and do not depend on production environment variables.

## Design Trade-offs

The in-memory repository keeps the enhancement focused on software architecture and API design, but its data is lost when the application stops. The repository interface isolates that limitation so a database implementation can be added later without rewriting the controller or business logic. HTTP Basic authentication is suitable for demonstrating protected endpoints, but a production deployment should also require HTTPS and would normally use a stronger identity system such as OAuth 2.0 or an external identity provider.
