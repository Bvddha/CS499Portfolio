import java.util.Objects;

public class Contact {
    private final String contactId;           
    private String firstName;                 
    private String lastName;                  
    private String phone;                     
    private String address;                   

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = validateId(contactId);
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    private static String requireNonNullTrim(String s, String field) {
        if (s == null) throw new IllegalArgumentException(field + " cannot be null");
        String t = s.trim();
        if (t.isEmpty()) throw new IllegalArgumentException(field + " cannot be blank");
        return t;
    }

    private static String validateId(String id) {
        String t = requireNonNullTrim(id, "Contact ID");
        if (t.length() > 10) throw new IllegalArgumentException("Contact ID must be at most 10 chars");
        return t;
    }

    private static String validateMaxLen(String value, String field, int max) {
        String t = requireNonNullTrim(value, field);
        if (t.length() > max) throw new IllegalArgumentException(field + " must be at most " + max + " chars");
        return t;
    }

    private static String validatePhone(String phone) {
        String t = requireNonNullTrim(phone, "Phone");
        if (!t.matches("\\d{10}")) throw new IllegalArgumentException("Phone must be exactly 10 digits");
        return t;
    }

    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName;  }
    public String getPhone()     { return phone;     }
    public String getAddress()   { return address;   }

    public void setFirstName(String firstName) { this.firstName = validateMaxLen(firstName, "First name", 10); }
    public void setLastName(String lastName)   { this.lastName  = validateMaxLen(lastName,  "Last name",  10); }
    public void setPhone(String phone)         { this.phone     = validatePhone(phone); }
    public void setAddress(String address)     { this.address   = validateMaxLen(address, "Address", 30); }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact c = (Contact) o;
        return Objects.equals(contactId, c.contactId);
    }
    @Override public int hashCode() { return Objects.hash(contactId); }
}
