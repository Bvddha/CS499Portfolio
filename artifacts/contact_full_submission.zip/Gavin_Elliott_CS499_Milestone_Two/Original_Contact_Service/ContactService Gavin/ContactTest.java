import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void constructor_valid_ok() {
        Contact c = new Contact("abc123", "Jane", "Doe", "1234567890", "123 Main Street, Unit 5");
        assertEquals("abc123", c.getContactId());
        assertEquals("Jane", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main Street, Unit 5", c.getAddress());
    }

    @Test
    void id_over_10_rejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("ABCDEFGHIJK", "Jane", "Doe", "1234567890", "Addr"));
    }

    @Test
    void first_last_max10_enforced() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id1", "FirstNameTooLong", "Doe", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id2", "Jane", "LastNameTooLong", "1234567890", "Addr"));
    }

    @Test
    void phone_must_be_exactly_10_digits() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id3", "Jane", "Doe", "12345", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id4", "Jane", "Doe", "12345678901", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id5", "Jane", "Doe", "123456789a", "Addr"));
    }

    @Test
    void address_max30_enforced() {
        String longAddr = "1234567890123456789012345678901"; 
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id6", "Jane", "Doe", "1234567890", longAddr));
    }

    @Test
    void setters_enforce_rules_and_id_is_not_updatable() {
        Contact c = new Contact("id7", "Jane", "Doe", "1234567890", "Addr");
        c.setFirstName("Ann");
        c.setLastName("Lee");
        c.setPhone("0987654321");
        c.setAddress("27 Short Rd");
        assertEquals("Ann", c.getFirstName());
        assertEquals("Lee", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("27 Short Rd", c.getAddress());
    }

    @Test
    void nulls_and_blanks_rejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id8", " ", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id9", "A", "", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id10", "A", "B", null, "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("id11", "A", "B", "1234567890", null));
    }
}
