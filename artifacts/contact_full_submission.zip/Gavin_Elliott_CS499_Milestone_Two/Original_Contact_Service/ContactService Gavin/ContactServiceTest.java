import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setup() {
        service = new ContactService();
        service.addContact("c1", "John", "Doe", "1112223333", "1 First St");
    }

    @Test
    void addContact_enforces_unique_id() {
        assertNotNull(service.getContact("c1"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addContact("c1", "Jane", "Smith", "4445556666", "2 Second St"));
    }

    @Test
    void deleteContact_removes_and_throws_if_missing() {
        service.deleteContact("c1");
        assertNull(service.getContact("c1"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("c1"));
    }

    @Test
    void update_first_last_phone_address_by_id() {
        service.updateFirstName("c1", "Amy");
        service.updateLastName("c1", "Wong");
        service.updatePhone("c1", "9998887777");
        service.updateAddress("c1", "9 Ninth Ave");

        Contact c = service.getContact("c1");
        assertEquals("Amy", c.getFirstName());
        assertEquals("Wong", c.getLastName());
        assertEquals("9998887777", c.getPhone());
        assertEquals("9 Ninth Ave", c.getAddress());
    }

    @Test
    void update_throws_if_id_not_found_or_values_invalid() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("bad", "X"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("c1", "123")); 
    }
}
