import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) throw new IllegalArgumentException("Contact cannot be null");
        String id = contact.getContactId();
        if (contacts.containsKey(id)) throw new IllegalArgumentException("Duplicate contact ID: " + id);
        contacts.put(id, contact);
    }

    public void addContact(String id, String first, String last, String phone, String address) {
        addContact(new Contact(id, first, last, phone, address));
    }

    public void deleteContact(String id) {
        if (id == null || !contacts.containsKey(id)) throw new IllegalArgumentException("Contact ID not found: " + id);
        contacts.remove(id);
    }

    public void updateFirstName(String id, String firstName) {
        getRequired(id).setFirstName(firstName);
    }

    public void updateLastName(String id, String lastName) {
        getRequired(id).setLastName(lastName);
    }

    public void updatePhone(String id, String phone) {
        getRequired(id).setPhone(phone);
    }

    public void updateAddress(String id, String address) {
        getRequired(id).setAddress(address);
    }

    public Contact getContact(String id) {
        return contacts.get(id);
    }
    private Contact getRequired(String id) {
        Contact c = contacts.get(id);
        if (c == null) throw new IllegalArgumentException("Contact ID not found: " + id);
        return c;
    }

    public Map<String, Contact> allContactsView() {
        return Collections.unmodifiableMap(contacts);
    }
}
